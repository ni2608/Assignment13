function splitIntoWords(str) {
    return str.split(" ");
}
