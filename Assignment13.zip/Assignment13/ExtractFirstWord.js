function extractFirstWord(sentence) {
    let words = sentence.split(" ");
    return words[0];
}
