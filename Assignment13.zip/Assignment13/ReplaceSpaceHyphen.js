function replaceSpacesWithHyphens(str) {
    return str.replace(/ /g, '-');
}
