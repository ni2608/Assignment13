function isPalindrome(str) {
    let reversedStr = '';
    
    for (let i = str.length - 1; i >= 0; i--) {
        reversedStr += str[i];
    }

    return str === reversedStr ? `${str} is a palindrome.` : `${str} is not a palindrome.`;
}
